<?php
/**
 * @package     Joomla.Site
 * @subpackage  com_content
 *
 * @copyright   Copyright (C) 2005 - 2016 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Layout\LayoutHelper;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Uri\Uri;
use Joomla\Component\Content\Site\Helper\RouteHelper;

$params = $this->item->params;
HTMLHelper::addIncludePath(JPATH_COMPONENT . '/helpers/html');
$canEdit   = $params->get('access-edit');
$info      = $params->get('info_block_position', 0);
$lineClamp = $this->params->get('line_clamp', '5');
?>

<div class="item-wrapper highlight">
    <?php echo LayoutHelper::render('joomla.content.intro_image', $this->item); ?>

    <div class="item-content">
        <?php $useDefList = ($params->get('show_modify_date') || $params->get('show_publish_date') || $params->get('show_create_date')
            || $params->get('show_hits') || $params->get('show_category') || $params->get('show_parent_category') || $params->get('show_author')); ?>

        <?php if ($params->get('show_tags') && !empty($this->item->tags->itemTags)) : ?>
            <?php echo LayoutHelper::render('joomla.content.tags', $this->item->tags->itemTags); ?>
        <?php endif; ?>

        <?php if ($useDefList && ($info == 0 || $info == 2)) : ?>
            <?php echo LayoutHelper::render('joomla.content.info_block.block', ['item' => $this->item, 'params' => $params, 'position' => 'above']); ?>
        <?php endif; ?>

        <?php if ($canEdit || $params->get('show_print_icon') || $params->get('show_email_icon')) : ?>
            <?php echo LayoutHelper::render('joomla.content.icons', ['params' => $params, 'item' => $this->item, 'print' => false]); ?>
        <?php endif; ?>

        <?php if (!$params->get('show_intro')) : ?>
            <?php echo $this->item->event->afterDisplayTitle; ?>
        <?php endif; ?>
        <?php echo $this->item->event->beforeDisplayContent; ?>

        <?php echo LayoutHelper::render('joomla.content.blog_style_default_item_title', $this->item); ?>

        <div style="--line-clamp:<?php echo (int) $lineClamp; ?>">
            <div><?php echo $this->item->introtext; ?></div>
        </div>

        <?php if ($useDefList && ($info == 1 || $info == 2)) : ?>
            <?php echo LayoutHelper::render('joomla.content.info_block.block', ['item' => $this->item, 'params' => $params, 'position' => 'below']); ?>
        <?php endif; ?>

        <?php if ($params->get('show_readmore') && $this->item->readmore) : ?>
            <?php if ($params->get('access-view')) : ?>
                <?php $link = Route::_(RouteHelper::getArticleRoute($this->item->slug, $this->item->catid, $this->item->language)); ?>
            <?php else : ?>
                <?php
                $menu   = Factory::getApplication()->getMenu();
                $active = $menu->getActive();
                $itemId = $active ? $active->id : 0;
                $link   = new Uri(Route::_('index.php?option=com_users&view=login&Itemid=' . $itemId, false));
                $link->setVar('return', base64_encode(RouteHelper::getArticleRoute($this->item->slug, $this->item->catid, $this->item->language)));
                ?>
            <?php endif; ?>

            <?php echo LayoutHelper::render('joomla.content.readmore', ['item' => $this->item, 'params' => $params, 'link' => $link]); ?>
        <?php endif; ?>

        <?php echo $this->item->event->afterDisplayContent; ?>
    </div>
</div>
